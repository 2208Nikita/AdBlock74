package ru.adblock74.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread

class AdBlockVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private val alive = AtomicBoolean(false)
    private var worker: Thread? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, notification())
        if (!alive.get()) startTunnel()
        return START_STICKY
    }

    private fun startTunnel() {
        try {
            val builder = Builder()
                .setSession("AdBlock 74")
                .setMtu(1500)
                .addAddress("10.74.0.1", 32)
                .addDnsServer("10.74.0.2")
                .addRoute("10.74.0.2", 32)

            tun = builder.establish()
            if (tun == null) {
                stopSelf()
                return
            }
            alive.set(true)
            running = true
            worker = thread(name = "AdBlock74-DNS") { packetLoop() }
        } catch (_: Exception) {
            running = false
            alive.set(false)
            stopSelf()
        }
    }

    private fun packetLoop() {
        val fd = tun ?: return
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buffer = ByteArray(32767)
        while (alive.get()) {
            try {
                val length = input.read(buffer)
                if (length <= 0) continue
                val response = handleIpv4Packet(buffer, length)
                if (response != null) output.write(response)
            } catch (_: Exception) {
                if (alive.get()) continue
            }
        }
    }

    private fun handleIpv4Packet(packet: ByteArray, length: Int): ByteArray? {
        if (length < 28) return null
        val version = (packet[0].toInt() ushr 4) and 0x0f
        if (version != 4) return null
        val ihl = (packet[0].toInt() and 0x0f) * 4
        if (ihl < 20 || length < ihl + 8 || packet[9].toInt() != 17) return null
        val udpOffset = ihl
        val sourcePort = u16(packet, udpOffset)
        val destPort = u16(packet, udpOffset + 2)
        if (destPort != 53) return null
        val udpLength = u16(packet, udpOffset + 4)
        val dnsStart = udpOffset + 8
        val dnsLength = udpLength - 8
        if (dnsLength < 12 || dnsStart + dnsLength > length) return null

        val qname = readQueryName(packet, dnsStart, dnsLength)
        val blocked = qname.isNotBlank() && isBlocked(qname)
        val dnsResponse = if (blocked) {
            blockedCount.incrementAndGet()
            makeNxDomain(packet.copyOfRange(dnsStart, dnsStart + dnsLength))
        } else {
            forwardDns(packet.copyOfRange(dnsStart, dnsStart + dnsLength))
                ?: return null
        }
        return buildIpv4UdpResponse(packet, ihl, sourcePort, dnsResponse)
    }

    private fun forwardDns(query: ByteArray): ByteArray? {
        return try {
            val socket = DatagramSocket()
            try {
                if (!protect(socket)) return null
                socket.soTimeout = 2500
                val address = InetAddress.getByName("1.1.1.1")
                socket.send(DatagramPacket(query, query.size, address, 53))
                val response = ByteArray(4096)
                val reply = DatagramPacket(response, response.size)
                socket.receive(reply)
                response.copyOf(reply.length)
            } finally {
                socket.close()
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun makeNxDomain(query: ByteArray): ByteArray {
        val response = query.copyOf()
        if (response.size >= 4) {
            val flags = ((response[2].toInt() and 0xff) shl 8) or (response[3].toInt() and 0xff)
            val newFlags = (flags or 0x8000 or 0x0080) and 0xfff0 or 0x0003
            response[2] = (newFlags ushr 8).toByte()
            response[3] = newFlags.toByte()
            response[6] = 0
            response[7] = 0
            response[8] = 0
            response[9] = 0
            response[10] = 0
            response[11] = 0
        }
        return response
    }

    private fun buildIpv4UdpResponse(request: ByteArray, ipHeaderLength: Int, clientPort: Int, dns: ByteArray): ByteArray {
        val clientIp = request.copyOfRange(12, 16)
        val dnsIp = byteArrayOf(10, 74, 0, 2)
        val udpLength = 8 + dns.size
        val totalLength = 20 + udpLength
        val out = ByteArray(totalLength)
        out[0] = 0x45
        out[1] = 0
        put16(out, 2, totalLength)
        put16(out, 4, 0)
        put16(out, 6, 0x4000)
        out[8] = 64
        out[9] = 17
        System.arraycopy(dnsIp, 0, out, 12, 4)
        System.arraycopy(clientIp, 0, out, 16, 4)
        put16(out, 10, checksum(out, 0, 20))
        put16(out, 20, 53)
        put16(out, 22, clientPort)
        put16(out, 24, udpLength)
        put16(out, 26, 0)
        System.arraycopy(dns, 0, out, 28, dns.size)
        return out
    }

    private fun readQueryName(packet: ByteArray, offset: Int, dnsLength: Int): String {
        try {
            var p = offset + 12
            val end = offset + dnsLength
            val labels = mutableListOf<String>()
            while (p < end) {
                val n = packet[p++].toInt() and 0xff
                if (n == 0) break
                if (n > 63 || p + n > end) return ""
                labels.add(String(packet, p, n, Charsets.US_ASCII).lowercase())
                p += n
            }
            return labels.joinToString(".")
        } catch (_: Exception) { return "" }
    }

    private fun isBlocked(host: String): Boolean {
        if (host.isBlank()) return false
        return BLOCKED.any { host == it || host.endsWith(".$it") }
    }

    private fun checksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        while (i < offset + length) {
            val hi = data[i].toInt() and 0xff
            val lo = if (i + 1 < offset + length) data[i + 1].toInt() and 0xff else 0
            sum += (hi shl 8) or lo
            i += 2
        }
        while ((sum ushr 16) != 0L) sum = (sum and 0xffff) + (sum ushr 16)
        return sum.inv().toInt() and 0xffff
    }

    private fun u16(b: ByteArray, i: Int) = ((b[i].toInt() and 0xff) shl 8) or (b[i + 1].toInt() and 0xff)
    private fun put16(b: ByteArray, i: Int, value: Int) {
        b[i] = (value ushr 8).toByte()
        b[i + 1] = value.toByte()
    }

    private fun notification(): Notification {
        val channelId = "adblock74"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "AdBlock 74", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId) else Notification.Builder(this)
        return builder.setContentTitle("AdBlock 74")
            .setContentText("Фильтрация рекламных DNS-запросов включена")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        alive.set(false)
        running = false
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        super.onDestroy()
    }

    companion object {
        @Volatile var running = false
        val blockedCount = AtomicLong(0)
        private const val NOTIFICATION_ID = 740
        private val BLOCKED = setOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "adnxs.com", "adsrvr.org", "taboola.com",
            "outbrain.com", "app-measurement.com", "unityads.unity3d.com",
            "applovin.com", "adjust.com", "branch.io", "scorecardresearch.com",
            "analytics.google.com", "adcolony.com", "vungle.com", "mopub.com"
        )
    }
}
