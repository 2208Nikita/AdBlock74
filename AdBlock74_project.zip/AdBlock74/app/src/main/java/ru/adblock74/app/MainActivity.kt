package ru.adblock74.app

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var count: TextView
    private lateinit var toggle: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refresh()
    }

    private fun buildUi() {
        val bg = Color.rgb(12, 18, 31)
        val white = Color.WHITE
        val muted = Color.rgb(174, 188, 210)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(bg)
        }

        val title = TextView(this).apply {
            text = "AdBlock 74"
            textSize = 30f
            setTextColor(white)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Блокировщик рекламы для Android"
            textSize = 15f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            textSize = 20f
            setTextColor(white)
            gravity = Gravity.CENTER
            text = "Проверяем состояние…"
        }
        count = TextView(this).apply {
            textSize = 16f
            setTextColor(muted)
            gravity = Gravity.CENTER
            text = "Заблокировано: 0"
        }
        toggle = Button(this).apply {
            textSize = 17f
            text = "Включить защиту"
            setOnClickListener { toggleProtection() }
        }
        val note = TextView(this).apply {
            text = "Фильтрация DNS-запросов на телефоне. Интернет-трафик не отправляется на сторонний VPN-сервер.\n\nНекоторая реклама (например, встроенная в YouTube) таким способом не блокируется."
            textSize = 13f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }

        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        root.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 52 })
        root.addView(count, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12 })
        root.addView(toggle, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 30 })
        root.addView(note, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 36 })
        setContentView(root)
    }

    private fun toggleProtection() {
        if (AdBlockVpnService.running) {
            stopService(Intent(this, AdBlockVpnService::class.java))
            refresh()
            return
        }
        val prepare = VpnService.prepare(this)
        if (prepare != null) {
            @Suppress("DEPRECATION")
            startActivityForResult(prepare, REQUEST_VPN)
        } else {
            startVpn()
        }
    }

    @Deprecated("Deprecated by Android API, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_VPN && resultCode == RESULT_OK) startVpn()
    }

    private fun startVpn() {
        val intent = Intent(this, AdBlockVpnService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        status.postDelayed({ refresh() }, 700)
    }

    private fun refresh() {
        if (!::status.isInitialized) return
        val on = AdBlockVpnService.running
        status.text = if (on) "Защита включена" else "Защита выключена"
        toggle.text = if (on) "Выключить защиту" else "Включить защиту"
        count.text = "Заблокировано: ${AdBlockVpnService.blockedCount}"
    }

    companion object { private const val REQUEST_VPN = 7401 }
}
